# Placeholder model - replace via CI after first training run
